#include <iostream>
#include "roman.h"

using namespace std;

int main() {
    string numeral;
    romanType rt;
    numeral = rt.setNumeral(numeral);
    rt.getValue(numeral);
}